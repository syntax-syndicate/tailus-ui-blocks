import { BrandIcon } from '@components/utilities/Brand';
import { Home, Inbox, Menu, Settings, Store, Users, HelpCircle, Star, Building, Flag, Copy, BarChartIcon, Folder } from 'lucide-react';
import { Caption, Title } from '@tailus-ui/typography';
import { useState } from 'react';
import Button from '@tailus-ui/Button';
import { WorkspaceIcon } from '@components/WorkspaceIcon';
import { twMerge } from 'tailwind-merge';
import * as Link from '@components/Link';
import { IconLink } from './components/IconLink';
import Separator from '@tailus-ui/Separator';
import { Notifications } from '@components/Notifications';
import { UserSelect } from './components/UserSelect';

import { StackedCards } from '@components/dashboard/Overview';
import Orders from '@components/dashboard/OrdersTable';
import { TwoAreasChart } from '@components/dashboard/AreaCharts';
import { SimpleBarChart } from '@components/dashboard//BarChart';
import { Traffic } from '@components/dashboard/Traffic';
import { StackedAreaChart } from '@components/dashboard/StackedAreas';

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <>
      {/*
        Tailwindcss config 

        import { animations, components, grays, palettes, rounded, shade } from '@tailus/themer';

        export default {
          content : [],
          theme: {
            extend: {
              colors: {
                ...palettes.trust,
                gray: grays.neutral,
              },
            },
          },
          plugins: [animations, components, rounded, shade],
        };
        
        ____________________________________________________

        HTML

        <html lang="en" data-rounded="large" data-shade="900" />
        <body class="bg-gray-50 dark:bg-gray-950" />

      */}

      <div data-shade="900" className="grid h-screen w-full bg-gray-50 [grid-template-columns:auto_1fr] dark:bg-gray-950">
        <aside className="sticky top-0 flex h-screen">
          <div className="flex flex-col gap-4 p-4">
            <div className="flex w-10">
              <BrandIcon className="mx-auto" />
            </div>
            <div className="mt-4 space-y-1">
              <IconLink link="#" label="Home" isActive>
                <Home />
              </IconLink>
              <IconLink link="#" label="Store">
                <Store />
              </IconLink>
              <IconLink link="#" label="Team">
                <Users />
              </IconLink>
              <IconLink link="#" label="Inbox">
                <Inbox />
              </IconLink>
            </div>
            <div className="mt-4">
              <Caption hidden>Workspaces</Caption>
              <Separator className="my-4" />
              <div className="space-y-1">
                <IconLink link="#" label="Tailus UI React">
                  <WorkspaceIcon intent="primary" />
                </IconLink>
                <IconLink link="#" label="Tailus UI HTML">
                  <WorkspaceIcon intent="accent" />
                </IconLink>
                <IconLink link="#" label="Tailus UI Themer">
                  <WorkspaceIcon intent="gray" />
                </IconLink>
              </div>
            </div>
            <div className="mt-auto h-fit">
              <Separator className="my-4" />
              <div className="space-y-1">
                <IconLink link="#" label="Help">
                  <HelpCircle />
                </IconLink>
                <IconLink link="#" label="Settings">
                  <Settings />
                </IconLink>
              </div>
            </div>
          </div>
          <div
            className={twMerge(
              'w-0 scale-[0.98] overflow-hidden border-l opacity-0 transition-[width,opacity,transform] duration-300',
              isMenuOpen && 'w-56 scale-100 opacity-100'
            )}
          >
            <div className="h-full w-56 space-y-4 p-4">
              <UserSelect />
              <div className="space-y-1">
                <Link.Root link="#">
                  <Link.Icon>
                    <Inbox />
                  </Link.Icon>
                  <Link.Label>Inbox</Link.Label>
                </Link.Root>
                <Link.Root link="#">
                  <Link.Icon>
                    <Star />
                  </Link.Icon>
                  <Link.Label>Star</Link.Label>
                </Link.Root>
                <Link.Root link="#">
                  <Link.Icon>
                    <Users />
                  </Link.Icon>
                  <Link.Label>Users</Link.Label>
                </Link.Root>
                <Link.Root link="#">
                  <Link.Icon>
                    <BarChartIcon />
                  </Link.Icon>
                  <Link.Label>Stats</Link.Label>
                </Link.Root>
                <Link.Root link="#">
                  <Link.Icon>
                    <Copy />
                  </Link.Icon>
                  <Link.Label>Documents</Link.Label>
                </Link.Root>
                <Link.Root link="#">
                  <Link.Icon>
                    <Flag />
                  </Link.Icon>
                  <Link.Label>Ownership</Link.Label>
                </Link.Root>
                <Link.Root link="#">
                  <Link.Icon>
                    <Building />
                  </Link.Icon>
                  <Link.Label>Organization</Link.Label>
                </Link.Root>
                <Link.Root link="#">
                  <Link.Icon>
                    <Folder />
                  </Link.Icon>
                  <Link.Label>Folder</Link.Label>
                </Link.Root>
              </div>
            </div>
          </div>
        </aside>
        <main
          className={twMerge(
            'max-w-[calc(100vw-2.5rem)] overflow-auto border border-b-0 bg-[--ui-bg] shadow-md lg:mr-1 lg:mt-1 lg:rounded-t-[--card-radius]',
            isMenuOpen && 'border-l'
          )}
        >
          <div className="feedback-bg sticky top-0 z-10 border-b py-4">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-6">
              <div className="flex items-center gap-2">
                <Button.Root
                  size="sm"
                  variant="ghost"
                  intent="gray"
                  className="-ml-2 focus:bg-transparent dark:focus:bg-transparent"
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                >
                  <Button.Icon type="only">
                    <Menu />
                  </Button.Icon>
                </Button.Root>
                <Title size="base" weight="medium">
                  Dashboard
                </Title>
              </div>
              <div className="flex gap-3">
                <Button.Root size="sm">
                  <Button.Label>New</Button.Label>
                </Button.Root>
                <Notifications />
              </div>
            </div>
          </div>
          <div className="mx-auto max-w-6xl space-y-6 p-6">
            <StackedCards />
            <div className="mt-6 grid gap-6 lg:grid-cols-2">
              <TwoAreasChart />
              <SimpleBarChart />
              <Traffic />
              <StackedAreaChart />
            </div>
            <Orders />
          </div>
        </main>
      </div>
    </>
  );
}
