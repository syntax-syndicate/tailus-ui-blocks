export const MESCHAC_AVATAR = 'https://avatars.githubusercontent.com/u/47919550?v=4';
export const BERNARD_AVATAR = 'https://avatars.githubusercontent.com/u/31113941?v=4';
export const THEO_AVATAR = 'https://avatars.githubusercontent.com/u/68236786?v=4';
export const GLODIE_AVATAR = 'https://avatars.githubusercontent.com/u/99137927?v=4';
