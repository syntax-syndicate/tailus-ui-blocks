import Select from '@tailus-ui/Select';
import { Text } from '@tailus-ui/typography';
import { ChevronsUpDown } from 'lucide-react';
import { AdminAvatar } from './AdminAvatar';
import { type TriggerProps } from '@tailus/themer';
import { BERNARD_AVATAR, TAILUS_AVATAR } from './../const';

export const UserSelect = ({ variant = 'mixed' }: { variant?: TriggerProps['variant'] }) => {
  return (
    <Select.Root defaultValue="meschacirung">
      <Select.Trigger variant={variant} className="w-full pl-1.5 pr-2 py-2" aria-label="Accounts">
        <Select.Value />
        <Select.TriggerIcon size="sm" className="ml-auto mr-0.5">
          <ChevronsUpDown className="size-3.5" />
        </Select.TriggerIcon>
      </Select.Trigger>
      <Select.Portal>
        <Select.Content mixed sideOffset={4} position="popper" intent="gray" variant="soft" className="z-10 w-[--radix-select-trigger-width]">
          <Select.Item value="meschacirung" className="h-auto p-2">
            <Select.ItemText>
              <div className="grid gap-2.5 items-center [grid-template-columns:auto_1fr]">
                <AdminAvatar />
                <Text as="p" size="sm" neutral className="my-0">
                  Méschac Irung
                </Text>
              </div>
            </Select.ItemText>
          </Select.Item>
          <Select.Item value="tailus" className="h-auto p-2">
            <Select.ItemText>
              <div className="grid gap-2.5 items-center [grid-template-columns:auto_1fr]">
                <AdminAvatar src={TAILUS_AVATAR} />
                <Text as="p" size="sm" neutral className="my-0" align="left">
                  Tailus UI
                </Text>
              </div>
            </Select.ItemText>
          </Select.Item>
          <Select.Item value="ng" className="h-auto p-2">
            <Select.ItemText>
              <div className="grid gap-2.5 items-center [grid-template-columns:auto_1fr]">
                <AdminAvatar src={BERNARD_AVATAR} />
                <Text as="p" size="sm" neutral className="my-0" align="left">
                  Bernard Ng
                </Text>
              </div>
            </Select.ItemText>
          </Select.Item>
        </Select.Content>
      </Select.Portal>
    </Select.Root>
  );
};
